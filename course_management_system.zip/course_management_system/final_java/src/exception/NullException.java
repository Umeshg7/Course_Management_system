package exception;
public class NullException extends RuntimeException {
	 private static final long serialVersionUID = 1L;
		public NullException() {
			super("Please Fill the Empty Boxes");
		}

}
