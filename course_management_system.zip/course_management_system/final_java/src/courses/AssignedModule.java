package courses;

public class AssignedModule {
    public int instructorId;
    public String moduleName;
    public AssignedModule(int instructorId, String moduleName) {
        this.instructorId = instructorId;
        this.moduleName = moduleName;
    }
}
